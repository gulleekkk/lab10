var data = [];
for (var i = 0; i < 100; i++) {
  data.push({
    x: Math.random() * 500,
    y: Math.random() * 500
  });
}

var xScale = d3.scaleLinear()
  .domain([0, 500])
  .range([0, 500]);

var yScale = d3.scaleLinear()
  .domain([0, 500])
  .range([0, 500]);


d3.select('#scatter-plot')
  .selectAll('circle')
  .data(data)
  .enter()
  .append('circle')
  .attr('cx', function(d) { return xScale(d.x); })
  .attr('cy', function(d) { return yScale(d.y); })
  .attr('r', 5);


d3.csv('titanic.csv').then(function(data) {
  // Compute the age distribution
  var ageDistribution = d3.rollup(data, 
    v => v.length, 
    d => d.Age
  );

  ageDistribution = Array.from(ageDistribution, 
    ([age, count]) => ({ age: age, count: count })
  );


  var pie = d3.pie()
    .value(function(d) { return d.count; });

  var arc = d3.arc()
    .innerRadius(0)
    .outerRadius(200);

  var color = d3.scaleOrdinal()
    .range(d3.schemeCategory10);

  var pieChart = d3.select('#pie-chart')
    .selectAll('path')
    .data(pie(ageDistribution))
    .enter()
    .append('path')
    .attr('d', arc)
    .attr('fill', function(d) { return color(d.data.age); })
    .attr('transform', 'translate(250,250)');
});
